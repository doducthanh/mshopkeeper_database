//
//  Stock.swift
//  MShopKeeper
//
//  Created by ddthanh on 3/9/18.
//  Copyright © 2018 ddthanh. All rights reserved.
//

import Foundation

class Stock {
    
    var stockId: String = ""
    var stockName: String = ""
}
