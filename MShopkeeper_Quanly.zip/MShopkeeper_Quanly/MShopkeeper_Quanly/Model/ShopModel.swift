//
//  ShopModel.swift
//  MShopkeeper_Quanly
//
//  Created by Admin on 4/11/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import Foundation

class ShopModel {
    
}
