//
//  Supplier.swift
//  MShopKeeper
//
//  Created by ddthanh on 3/9/18.
//  Copyright © 2018 ddthanh. All rights reserved.
//

import Foundation

class Supplier {
    
    var supplierID: String = ""
    var supplierName: String = ""
    
}
