//
//  Shop.swift
//  MShopKeeper
//
//  Created by ddthanh on 3/9/18.
//  Copyright © 2018 ddthanh. All rights reserved.
//

import Foundation

class Shop {
    
    var shopID: Int = 0
    var shopCode: String! = ""
    var shopName: String! = ""
    var contactName: String! = ""
    var parentShopID: Int = 0
    var tel: String = ""
    var address: String = ""
    
}
