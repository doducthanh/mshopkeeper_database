//
//  TopRevenueTableViewCell.swift
//  MShopkeeper_Quanly
//
//  Created by Admin on 5/6/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit

class TopRevenueTableViewCell: UITableViewCell {

    @IBOutlet var lbShopName: UILabel!
    @IBOutlet var lbShopRevenue: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
