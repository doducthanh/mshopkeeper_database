//
//  TextFieldMode.swift
//  MShopKeeper
//
//  Created by ddthanh on 3/14/18.
//  Copyright © 2018 ddthanh. All rights reserved.
//

import Foundation
import UIKit

class TextFieldMode{
    
    var arrayTextfield: [UITextField] = [UITextField]()
    
}
