//
//  Model.swift
//  MShopKeeper
//
//  Created by ddthanh on 3/19/18.
//  Copyright © 2018 ddthanh. All rights reserved.
//

import Foundation

class Model {
//    khai báo các thuộc tính của đối tượng model
    var modelID = 0
    var shopID = 0
    var modelName = ""
    var modelType = 0
    var decription = ""
    var pictureLink = ""
    var picturetype = 0
    var unitPrice = 0
    var isDisplayPrice = true
    var dateOfEntry = ""
    var isPromtion = false
    var percentPromtion = 0.0
    var saleCount = 0
    var dataImage: Data?
}
