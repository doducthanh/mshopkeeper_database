//
//  MyColors.swift
//  MShopKeeper
//
//  Created by ddthanh on 2/6/18.
//  Copyright © 2018 ddthanh. All rights reserved.
//

import Foundation
import UIKit

//class định nghĩa các màu dùng trong project
class MyColors{
    public static let BACKGROUND_BUTTON_DEFAULT = UIColor.init(red: 232/255.0, green: 232/255.0, blue: 232/255.0, alpha: 1)
    public static let BLUE = UIColor.init(red: 64/255.0, green: 127/255.0, blue: 174/255.0, alpha: 1)
}


